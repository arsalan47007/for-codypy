from django.shortcuts import render
from django.http import HttpResponse


from checkins.forms import MoodEntryForm

def home(requests):
    # return HttpResponse("Welcome to my website")
    return render(requests, "checkins/home.html")


def get_form(requests):
    if requests.method == 'POST':
        my_form = MoodEntryForm(requests.POST)
        print(my_form)
        if my_form.is_valid():
            my_form.save()
            return HttpResponse("add success!")
    else:
        my_form = MoodEntryForm()

    return render(
        requests,
        "checkins/entry_form.html",
        {"django_form": my_form}
    )
