from django.urls import path

from checkins.views import home, get_form

urlpatterns = [
    path('home/', home),
    path('add/', get_form)
]
