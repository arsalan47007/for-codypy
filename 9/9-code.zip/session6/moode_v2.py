import json

with open("mood_entries.json", "r", encoding="utf-8") as file:
    datas = json.load(file)
    print("finish load json file")

print(datas)

def get_mood_status(score: int):
    if score >= 4:
        status = "good"
    elif score == 3:
        status = "normal"
    else:
        status = "needs attention"

    return status

for data in datas:
    user_status = get_mood_status(data["score"])
    data["status"] = user_status
    print(data["name"], user_status, data)

print("--" * 10)
print("start to write json file")

with open("mood_entries_v3.json", "w", encoding="utf-8") as file:
    json.dump(datas, file)

print("finish write json file")
