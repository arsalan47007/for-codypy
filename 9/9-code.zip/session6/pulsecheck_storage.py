import json

DATA_FILE = "mood_entries.json"


def load_entries():
    with open(DATA_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def save_entries(datas):
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(datas, file, ensure_ascii=False, indent=2)


entries = load_entries()

new_entry = {
    "name": "مینا",
    "score": 5,
    "reason": "فهمیدن تابع"
}

entries.append(new_entry)
save_entries(entries)

print(f"Saved {len(entries)} entries.")
