from django.urls import path

from checkins.views import home, get_form, report

urlpatterns = [
    path('home/', home),
    path('add/', get_form),
    path('report/', report, name='report')
]
